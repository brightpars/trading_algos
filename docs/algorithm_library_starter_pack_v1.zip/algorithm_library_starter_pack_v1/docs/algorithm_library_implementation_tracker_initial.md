# Algorithm Library Implementation Tracker — Initial Generated Version

> This file is generated from the starter-pack manifest. It is intended as the first repository-native tracker, not as a hand-maintained spreadsheet.

## Source metadata

- Requirements document path: `docs/algorithm_library_requirements_v4.md`
- Requirements document version: `4`
- Implementation plan path: `docs/algorithm_library_systematic_implementation_plan_v2.md`
- Total algorithm rows: **121**
- Total combination-method rows: **12**
- Total tracked rows: **133**

## Overall status summary

| metric | count |
| --- | --- |
| algorithm rows | 121 |
| combination-method rows | 12 |
| ready_to_implement | 50 |
| blocked_framework | 83 |
| in_progress | 0 |
| complete | 0 |
| prototype_only | 133 |
| research_ready | 0 |
| production_ready | 0 |
| tier1 rows | 45 |
| tier2 rows | 53 |
| tier3 rows | 35 |

## Family summary

| family | kind_mix | total | ready | blocked | in_progress | complete | current_batches |
| --- | --- | --- | --- | --- | --- | --- | --- |
| adaptive_state_based | combination_method | 1 | 0 | 1 | 0 | 0 | composite_wave_3 |
| cross_asset_macro_carry | algorithm | 8 | 0 | 8 | 0 | 0 | cross_asset_wave_1 |
| event_driven | algorithm | 5 | 0 | 5 | 0 | 0 | event_wave_1 |
| execution | algorithm | 6 | 0 | 6 | 0 | 0 | advanced_wave_blocked |
| factor_risk_premia | algorithm | 15 | 0 | 15 | 0 | 0 | factor_wave_1, factor_wave_2, factor_wave_3 |
| fixed_income_relative_value | algorithm | 2 | 0 | 2 | 0 | 0 | relative_value_wave_2 |
| fundamental_ml_composite | algorithm | 8 | 0 | 8 | 0 | 0 | advanced_model_wave_1, factor_wave_2, factor_wave_3 |
| machine_learning_ensemble | combination_method | 3 | 3 | 0 | 0 | 0 | composite_wave_4 |
| mean_reversion | algorithm | 12 | 12 | 0 | 0 | 0 | mean_reversion_wave_1, mean_reversion_wave_2, mean_reversion_wave_3 |
| microstructure_hft | algorithm | 8 | 0 | 8 | 0 | 0 | advanced_wave_blocked |
| momentum | algorithm | 11 | 7 | 4 | 0 | 0 | momentum_wave_1, momentum_wave_2, momentum_wave_3 |
| optimization_based | combination_method | 1 | 0 | 1 | 0 | 0 | composite_wave_3 |
| pattern_price_action | algorithm | 8 | 8 | 0 | 0 | 0 | pattern_wave_1, pattern_wave_2 |
| reinforcement_learning | combination_method | 2 | 0 | 2 | 0 | 0 | composite_wave_5 |
| risk_overlay | combination_method | 2 | 1 | 1 | 0 | 0 | composite_wave_2 |
| rule_based_combination | combination_method | 3 | 2 | 1 | 0 | 0 | composite_contract_wave_1, composite_wave_2 |
| stat_arb | algorithm | 14 | 0 | 14 | 0 | 0 | relative_value_wave_2, stat_arb_wave_1 |
| trend | algorithm | 14 | 14 | 0 | 0 | 0 | trend_wave_1, trend_wave_2, trend_wave_3 |
| volatility_options | algorithm | 10 | 3 | 7 | 0 | 0 | volatility_wave_1, volatility_wave_2 |

## Framework blockers summary

| blocker_key | status | affected_rows | affected_families |
| --- | --- | --- | --- |
| blocker.multi_asset_panel_v1 | planned | 38 | cross_asset_macro_carry, factor_risk_premia, fundamental_ml_composite, momentum, optimization_based... |
| blocker.rebalance_engine_v1 | planned | 38 | cross_asset_macro_carry, factor_risk_premia, fundamental_ml_composite, momentum, optimization_based... |
| blocker.portfolio_weight_output_v1 | planned | 29 | factor_risk_premia, fundamental_ml_composite, momentum, optimization_based, risk_overlay |
| blocker.multi_leg_reporting_v1 | planned | 19 | cross_asset_macro_carry, fixed_income_relative_value, stat_arb |
| blocker.spread_leg_output_v1 | planned | 19 | cross_asset_macro_carry, fixed_income_relative_value, stat_arb |
| blocker.hedge_ratio_helpers_v1 | planned | 16 | fixed_income_relative_value, stat_arb |
| blocker.order_book_input_v1 | planned | 8 | microstructure_hft |
| blocker.own_order_state_v1 | planned | 8 | microstructure_hft |
| blocker.greeks_v1 | planned | 7 | volatility_options |
| blocker.options_chain_v1 | planned | 7 | volatility_options |
| blocker.event_calendar_v1 | planned | 6 | cross_asset_macro_carry, event_driven |
| blocker.event_reporting_v1 | planned | 6 | cross_asset_macro_carry, event_driven |
| blocker.event_window_execution_v1 | planned | 6 | cross_asset_macro_carry, event_driven |
| blocker.execution_plan_output_v1 | planned | 6 | execution |
| blocker.fill_simulation_v1 | planned | 6 | execution |
| blocker.rl_environment_v1 | planned | 2 | reinforcement_learning |
| blocker.regime_state_support_v1 | planned | 1 | adaptive_state_based |

## Next-ready batches

| batch | ready_rows |
| --- | --- |
| trend_wave_1 | 5 |
| trend_wave_2 | 5 |
| momentum_wave_1 | 5 |
| mean_reversion_wave_1 | 5 |
| pattern_wave_1 | 5 |
| trend_wave_3 | 4 |
| mean_reversion_wave_2 | 4 |
| mean_reversion_wave_3 | 3 |
| volatility_wave_1 | 3 |
| pattern_wave_2 | 3 |
| composite_wave_4 | 3 |
| momentum_wave_2 | 2 |
| composite_contract_wave_1 | 2 |
| composite_wave_2 | 1 |

## Fixture coverage

| metric | count |
| --- | --- |
| rows with at least one fixture id | 133 |
| rows missing fixture ids | 0 |
| registered fixtures in registry | 28 |
| performance budgets in registry | 9 |

## Notes

- In this initial version, rows are seeded mostly as either `ready_to_implement` or `blocked_framework`.
- No rows are marked `in_progress`, `tested`, `documented`, or `complete` yet.
- Operational readiness starts at `prototype_only` for all rows.
- The main purpose of this initial tracker is to make totals, blockers, and batch ordering explicit from day one.
